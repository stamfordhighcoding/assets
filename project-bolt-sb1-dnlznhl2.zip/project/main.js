import * as THREE from 'three';

//create a new scene
const scene = new THREE.Scene()
            
//what you want to add to the scene:
const cubeGeometry = new THREE.BoxGeometry(1,1,1)
const cubeMaterial = new THREE.MeshBasicMaterial({color: "blue"})//(will not respond to light)
            
const cubeMesh = new THREE.Mesh(
    cubeGeometry,
    cubeMaterial
)
scene.add(cubeMesh)
            
// initialize the camera
const camera = new THREE.PerspectiveCamera(
    75, 
    window.innerWidth / window.innerHeight,
    0.1, //dont see anything closer than this distance
    30 //dont see anything farther than this distance
)
            
// position (of the camera)
camera.position.z = 5
scene.add(camera)
            
// initialize the renderer
const canvas = document.querySelector('canvas.threejs')
const renderer = new THREE.WebGLRenderer({
     canvas: canvas
})
            
//final step for canvas drawing
renderer.setSize(window.innerWidth, window.innerHeight)//by default will be small
renderer.render(scene, camera)